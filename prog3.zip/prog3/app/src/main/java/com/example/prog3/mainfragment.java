package com.example.prog3;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;


public class mainfragment extends Fragment {

Button b1,b2;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_mainfragment, container, false);
        b1=view.findViewById(R.id.btn1);
        b2=view.findViewById(R.id.btn2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.action_mainfragment_to_fragment1);
                Toast.makeText(getContext(),"Fragment 1",Toast.LENGTH_SHORT).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(view).navigate(R.id.action_mainfragment_to_fragment2);
                Toast.makeText(getContext(),"Fragment 2",Toast.LENGTH_SHORT).show();
            }
        });
        return view;

    }
}