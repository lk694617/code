package com.example.prog2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn=findViewById(R.id.button);
        Switch sw=findViewById(R.id.switch1);
        ConstraintLayout layout=findViewById(R.id.lay);
        CalendarView cl=new CalendarView(MainActivity.this);
        layout.addView(cl);
        sw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw.isChecked())
                {
                    btn.setEnabled(true);
                    layout.setBackgroundResource(R.drawable.astro);
                    layout.removeView(cl);
                    Toast.makeText(MainActivity.this,"Button is Enabled",Toast.LENGTH_LONG).show();
                }
                else{
                    btn.setEnabled(false);
                    layout.addView(cl);
                    layout.setBackgroundResource(R.drawable.index);
                    Toast.makeText(MainActivity.this,"Button is Disable",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(MainActivity.this,"App is in Pause Sate",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(MainActivity.this,"App is Resume",Toast.LENGTH_LONG).show();
    }
}